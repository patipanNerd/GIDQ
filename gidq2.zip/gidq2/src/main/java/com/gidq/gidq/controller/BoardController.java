package com.gidq.gidq.controller;

import com.gidq.gidq.model.*;
import com.gidq.gidq.repository.*;
import javafx.concurrent.Task;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class BoardController {

    @Autowired
    BoardRepository boardRepository;

    @Autowired
    TaskListRepository taskListRepository;

    @Autowired
    TaskCardRepository taskCardRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ChatMessageRepository chatMessageRepository;

    @Autowired
    ChatRepository chatRepository;

    @Autowired
    NotificationRepository notificationRepository;

    @GetMapping("/AllProject")
    public String showAllBoard(ModelMap model , HttpServletRequest request) {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        model.addAttribute("currentUser",currentUser);

        List<Board> allBoard = boardRepository.findAllByUserAndIsFavoriteIsFalse(currentUser);
        model.addAttribute("allBoard", allBoard);

        List<Board> allFavBoard = boardRepository.findAllByUserAndIsFavoriteIsTrue(currentUser);
        model.addAttribute("allFavBoard", allFavBoard);

        List<Notification> allNoti = notificationRepository.findAllByReceiveUserID(currentUser.getUserID());
        model.addAttribute("allNoti",allNoti);

        int unReadCount=0;
        for(int i=0;i<allNoti.size();i++){
            if(!allNoti.get(i).isRead()){
                unReadCount++;
            }
        }

        model.addAttribute("unReadCount",unReadCount);

        return "AllProject";
    }

    @GetMapping("/AllProject/changeToFav/{boardID}")
    public String changeToFav(ModelMap model, @PathVariable Long boardID) {
        Board targetBoard = boardRepository.findByBoardID(boardID);
        targetBoard.setIsFavorite(true);
        boardRepository.save(targetBoard);

        List<Board> allBoard = boardRepository.findAllByIsFavoriteIsFalse();
        model.addAttribute("allBoard", allBoard);

        List<Board> allFavBoard = boardRepository.findAllByIsFavoriteIsTrue();
        model.addAttribute("allFavBoard", allFavBoard);

        return "redirect:/AllProject";
    }

    @GetMapping("/AllProject/changeToUnFav/{boardID}")
    public String changeToUnFav(ModelMap model, @PathVariable Long boardID) {
        Board targetBoard = boardRepository.findByBoardID(boardID);
        targetBoard.setIsFavorite(false);
        boardRepository.save(targetBoard);

        List<Board> allBoard = boardRepository.findAllByIsFavoriteIsFalse();
        model.addAttribute("allBoard", allBoard);

        List<Board> allFavBoard = boardRepository.findAllByIsFavoriteIsTrue();
        model.addAttribute("allFavBoard", allFavBoard);

        return "redirect:/AllProject";
    }

    @PostMapping("/AllProject/addedProject")
    public String addBoard(ModelMap model, HttpServletRequest request) {
        String name = request.getParameter("boardName");
        String description = request.getParameter("boardDescription");
        User currentUser = (User) request.getSession().getAttribute("currentUser");

        List<Board> boardTemp = boardRepository.findAll();

        Board board = new Board(boardTemp.size() + 1L, name, description, "white", false);

        List<User> userList = new ArrayList<>();

        userList.add(currentUser);
        board.setUser(userList);
        boardRepository.save(board);

        Chat chat = new Chat(boardTemp.size()+1L,name);
        chat.setUser(userList);
        chatRepository.save(chat);

        List<Board> allBoard = boardRepository.findAllByIsFavoriteIsFalse();
        model.addAttribute("allBoard", allBoard);

        List<Board> allFavBoard = boardRepository.findAllByIsFavoriteIsTrue();
        model.addAttribute("allFavBoard", allFavBoard);

        return "redirect:/AllProject";
    }


    @GetMapping("/Board/{boardID}/addedTaskList")
    public String addTaskList(ModelMap model, @PathVariable Long boardID) {
        setDate(boardID);
        String[] colorCode = {"#2a56c6","#a52714","#ee8100","#0b8043","#6a1b9a","#00838f","#e64a19","#827717","#3949ab","#e91e63","#004d40","#880e4f"};

        List<TaskList> listTemp = taskListRepository.findAll();
        Board boardTemp = boardRepository.findByBoardID(boardID);

        TaskList newList = new TaskList(listTemp.size() + 1L, "insert list name", 0);
        newList.setBoard(boardTemp);

        List<TaskList> listForColorCode = taskListRepository.findAllByBoard_BoardID(boardID);

        for(int i=0;i<colorCode.length;i++){
            if(listForColorCode.size() != 0){
                if(colorCode[i].equals(listForColorCode.get(listForColorCode.size()-1).getColorCode())){
                    newList.setColorCode(colorCode[i+1]);
                    break;
                }
                System.out.println(123);
            }else{
                newList.setColorCode(colorCode[0]);
                System.out.println(456);
            }
        }

        taskListRepository.save(newList);

        Date date = new Date();
        String notiDes = "Task List has been added in Board " + boardTemp.getBoardName();
        String notiHeader = boardTemp.getBoardName();
        String url = "/Board/" + boardID;

        List<User> userList = boardTemp.getUser();
        for(int i =0;i<userList.size();i++){
            List<Notification> notificationsList = notificationRepository.findAll();
            if(notificationsList.size() !=0){
                Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }else{
                Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }
        }


        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        model.addAttribute("allList", allList);

        return "redirect:/Board/" + boardID;
    }

    @GetMapping("/Board/{boardID}/{listID}/addedTaskCard")
    public String addTaskCard(ModelMap model, @PathVariable Long boardID, @PathVariable Long listID) {
        setDate(boardID);

        List<TaskCard> cardTemp = taskCardRepository.findAll();
        TaskList listTemp = taskListRepository.findByListID(listID);
        List<TaskCard> cardTempInList = listTemp.getTaskCard();
        Date startDate = new Date();
        Date dueDate = new Date();
        TaskCard taskCard;

        if(cardTemp.size() == 0){
            taskCard = new TaskCard(cardTemp.size()+1L, "", "");
        }else{
            taskCard = new TaskCard(cardTemp.get(cardTemp.size()-1).getTaskCardID() + 1L, "", "");
        }

        taskCard.setTaskList(listTemp);
        taskCardRepository.save(taskCard);

        cardTempInList.add(taskCard);
        listTemp.setCardQuantity(listTemp.getCardQuantity() + 1);
        listTemp.setTaskCard(cardTempInList);
        taskListRepository.save(listTemp);


        Board boardTemp = boardRepository.findByBoardID(boardID);
        Date date = new Date();
        String notiDes = "Task card has been added in Task List " + listTemp.getListName() + " in Board " + listTemp.getBoard().getBoardName();
        String notiHeader = boardTemp.getBoardName() + " > " + listTemp.getListName();
        String url = "/Board/" + boardID;

        List<User> userList = boardTemp.getUser();
        for(int i =0;i<userList.size();i++){
            List<Notification> notificationsList = notificationRepository.findAll();
            if(notificationsList.size() !=0){
                Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }else{
                Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }
        }

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        model.addAttribute("allList", allList);

        return "redirect:/Board/" + boardID;
    }


    @PostMapping("/Board/{boardID}/updatedTaskListName")
    public String updateTaskListName(ModelMap model, HttpServletRequest request, @PathVariable Long boardID) {
        setDate(boardID);
        String name = request.getParameter("taskListName");
        String taskListID = request.getParameter("editedListID");

        Long id = Long.parseLong(taskListID);

        TaskList taskListTemp = taskListRepository.findByListID(id);

        Board boardTemp = boardRepository.findByBoardID(boardID);
        Date date = new Date();
        String notiDes = "Task List name has been changed";
        String notiHeader = boardTemp.getBoardName() + " > " + name;
        String url = "/Board/" + boardID;

        List<User> userList = boardTemp.getUser();
        for(int i =0;i<userList.size();i++){
            List<Notification> notificationsList = notificationRepository.findAll();
            if(notificationsList.size() !=0){
                Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }else{
                Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }
        }

        taskListTemp.setListName(name);

        taskListRepository.save(taskListTemp);

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        model.addAttribute("allList", allList);


        return "redirect:/Board/" + boardID;
    }

    @PostMapping("/Board/{boardID}/updatedTaskCardName")
    public String updateTaskCardName(ModelMap model, HttpServletRequest request, @PathVariable Long boardID) {
        setDate(boardID);
        String name = request.getParameter("taskCardName");
        String taskCardID = request.getParameter("editedCardID");

        Long id = Long.parseLong(taskCardID);

        TaskCard taskCardTemp = taskCardRepository.findByTaskCardID(id);

        Board boardTemp = boardRepository.findByBoardID(boardID);
        Date date = new Date();
        String notiDes = "Task Card name has been changed";
        String notiHeader = boardTemp.getBoardName() + " > " + taskCardTemp.getTaskList().getListName() + " > " + name;
        String url = "/Board/" + boardID;

        List<User> userList = boardTemp.getUser();
        for(int i =0;i<userList.size();i++){
            List<Notification> notificationsList = notificationRepository.findAll();
            if(notificationsList.size() !=0){
                Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }else{
                Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }
        }

        taskCardTemp.setCardName(name);

        taskCardRepository.save(taskCardTemp);

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        model.addAttribute("allList", allList);


        return "redirect:/Board/" + boardID;
    }



    @PostMapping("/Board/{boardID}/updatedTaskCard")
    public String updateTask(ModelMap model, HttpServletRequest request, @PathVariable Long boardID) {
        setDate(boardID);
        String description = request.getParameter("modalDescription");
        String startDateTemp = request.getParameter("modalStartDate");
        String dueDateTemp = request.getParameter("modalDueDate");
        String taskCardID = request.getParameter("modalCardID");
        String percent = request.getParameter("percentDone");
        int percentDone = Integer.parseInt(percent);

        Long id = Long.parseLong(taskCardID);

        Board boardTemp = boardRepository.findByBoardID(boardID);
        TaskCard taskCardTemp = taskCardRepository.findByTaskCardID(id);

        for(int i=1;i<boardTemp.getUser().size()+1;i++){
            String url = "assignToUser" + i;
            String assignIDString = request.getParameter(url);
            if(assignIDString != null){
                Long assignID = Long.parseLong(assignIDString);
                User assignedUser = userRepository.findByUserID(assignID);

                List<TaskCard> assignedTaskCard = assignedUser.getAssignedTaskCard();
                boolean found = false;

                if(assignedTaskCard.size() ==0){
                    assignedTaskCard.add(taskCardTemp);
                    assignedUser.setAssignedTaskCard(assignedTaskCard);
                    userRepository.save(assignedUser);
                }else{
                    for(int j=0;j<assignedTaskCard.size();j++){
                        if(assignedTaskCard.get(j).getTaskCardID().equals(taskCardTemp.getTaskCardID())){
                            found = true;
                            break;
                        }
                    }
                    if(!found){
                        assignedTaskCard.add(taskCardTemp);
                        assignedUser.setAssignedTaskCard(assignedTaskCard);
                        userRepository.save(assignedUser);
                    }
                }
            }else{
                Long assignID = (long) i;
                User assignedUser = userRepository.findByUserID(assignID);
                List<TaskCard> assignedTaskCard = new ArrayList<>();

                for(int j=0;j<assignedUser.getAssignedTaskCard().size();j++){
                    if(!assignedUser.getAssignedTaskCard().get(j).getTaskCardID().equals(id)){
                        TaskCard tempCard = taskCardRepository.findByTaskCardID(assignedUser.getAssignedTaskCard().get(j).getTaskCardID());
                        assignedTaskCard.add(tempCard);
                    }
                }

                assignedUser.setAssignedTaskCard(assignedTaskCard);
                userRepository.save(assignedUser);

            }
        }

        DateFormat startDateDF = new SimpleDateFormat("yyyy/MM/dd");
        DateFormat dueDateDF = new SimpleDateFormat("yyyy/MM/dd");
        Date startDate;
        Date dueDate;
        try {
            startDate = startDateDF.parse(startDateTemp);
            dueDate = dueDateDF.parse(dueDateTemp);

            taskCardTemp.setStartDate(startDate);
            taskCardTemp.setDueDate(dueDate);

        } catch (ParseException e){
            e.printStackTrace();
        }

        taskCardTemp.setDescription(description);
        taskCardTemp.setPercent(percentDone);

        taskCardRepository.save(taskCardTemp);


        Date date = new Date();
        String notiDes = "Task Card " + taskCardTemp.getCardName() +" has been updated";
        String notiHeader = boardTemp.getBoardName() + " > " + taskCardTemp.getTaskList().getListName() + " > " + taskCardTemp.getCardName();
        String url = "/Board/" + boardID;

        List<User> userList = boardTemp.getUser();
        for(int i =0;i<userList.size();i++){
            List<Notification> notificationsList = notificationRepository.findAll();
            if(notificationsList.size() !=0){
                Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }else{
                Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }
        }

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        model.addAttribute("allList", allList);

        request.getSession().setAttribute("currentCardID",id);

        return "redirect:/Board/" + boardID;
    }

    @PostMapping("/Board/{boardID}/InviteToBoard")
    public String addUserToBoard(ModelMap model,HttpServletRequest request,@PathVariable Long boardID) {
        String email = request.getParameter("member-email");

        Board boardTemp = boardRepository.findByBoardID(boardID);
        Date date = new Date();
        String notiDes = "You have been added to board "+boardTemp.getBoardName();
        String notiHeader = boardTemp.getBoardName();
        String url = "/Board/" + boardID;

        User user = userRepository.findByEmail(email);

        List<Notification> notificationsList = notificationRepository.findAll();
        if(notificationsList.size() !=0){
            Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
            notification.setReceiveUserID(user.getUserID());
            notification.setHeader(notiHeader);
            notification.setUrl(url);
            notificationRepository.save(notification);
        }else{
            Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
            notification.setReceiveUserID(user.getUserID());
            notification.setHeader(notiHeader);
            notification.setUrl(url);
            notificationRepository.save(notification);
        }



        List<User> userList = boardTemp.getUser();
        boolean found=false;

        for(int i=0;i<userList.size();i++){
            if(userList.get(i).getEmail().equals(email)){
                found = true;
                break;
            }
        }
        if(!found){
            userList.add(user);
            boardTemp.setUser(userList);
            boardRepository.save(boardTemp);

            Chat chat = chatRepository.findByChatID(boardID);
            List<User> userListForChat = chat.getUser();
            userListForChat.add(user);
            chat.setUser(userListForChat);
            chatRepository.save(chat);
        }



        return "redirect:/Board/" + boardID;
    }


    @GetMapping("/Board/{boardID}/{taskListID}/{taskCardID}/deleteTaskCard")
    public String deleteTask(ModelMap model, HttpServletRequest request, @PathVariable Long boardID , @PathVariable Long taskListID ,@PathVariable Long taskCardID) {
        setDate(boardID);

        TaskCard taskCardTemp = taskCardRepository.findByTaskCardID(taskCardID);
        TaskList taskListTemp = taskListRepository.findByListID(taskListID);

        List<User> userTemp = userRepository.findAll();

        for(int i=0;i<userTemp.size();i++){
            for(int j=0;j<userTemp.get(i).getAssignedTaskCard().size();j++){
                if(userTemp.get(i).getAssignedTaskCard().get(j).getTaskCardID().equals(taskCardID)){
                    Long a = userTemp.get(i).getAssignedTaskCard().get(j).getTaskCardID();
                    TaskCard deletedTaskCard = taskCardRepository.findByTaskCardID(a);
                    List<TaskCard> tempCard = userTemp.get(i).getAssignedTaskCard();
                    tempCard.remove(deletedTaskCard);
                    userTemp.get(i).setAssignedTaskCard(tempCard);
                    userRepository.save(userTemp.get(i));
                }
            }
        }

        taskListTemp.setCardQuantity(taskListTemp.getCardQuantity()-1);
        taskCardRepository.delete(taskCardTemp);

        Board boardTemp = boardRepository.findByBoardID(boardID);
        Date date = new Date();
        String notiDes = "Task Card " + taskCardTemp.getCardName() +" has been deleted";
        String notiHeader = boardTemp.getBoardName() + " > " + taskCardTemp.getTaskList().getListName() + " > " + taskCardTemp.getCardName();
        String url = "/Board/" + boardID;

        List<User> userList = boardTemp.getUser();
        for(int i =0;i<userList.size();i++){
            List<Notification> notificationsList = notificationRepository.findAll();
            if(notificationsList.size() !=0){
                Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }else{
                Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
                notification.setReceiveUserID(userList.get(i).getUserID());
                notification.setHeader(notiHeader);
                notification.setUrl(url);
                notificationRepository.save(notification);
            }
        }

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        model.addAttribute("allList", allList);


        return "redirect:/Board/" + boardID;
    }

    @PostMapping("/Board/{boardID}/{chatID}/addedChatMessage")
    public ResponseEntity<ChatMessage> addChatMessage(ModelMap model, @PathVariable Long boardID, @PathVariable Long chatID,HttpServletRequest request,@RequestBody String ChatMessage) {
        setDate(boardID);
        setChatDate();
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        String message = request.getParameter("chatMessageField");
        Chat chat = chatRepository.findByChatID(chatID);
        Date date = new Date();

        List<ChatMessage> chatMessagesAll = chatMessageRepository.findAll();

        ChatMessage chatMessage = new ChatMessage(chatMessagesAll.size()+1L,ChatMessage,date,currentUser.getUserID());
        Date tempTimeStamp;
        DateFormat tempTimeStampDF = new SimpleDateFormat("EEEEE dd/MM/yyyy");
        DateFormat tempTimeStampDF2 = new SimpleDateFormat("HH:mm");
        String tempTimeStampString;
        String tempTimeStampString2;

        tempTimeStamp = chatMessage.getTimeStamp();
        tempTimeStampString = tempTimeStampDF.format(tempTimeStamp);
        tempTimeStampString2 = tempTimeStampDF2.format(tempTimeStamp);
        chatMessage.setDateString(tempTimeStampString);
        chatMessage.setTimeStampString(tempTimeStampString2);
        chatMessageRepository.save(chatMessage);
        setChatDate();

        List<ChatMessage> chatMessagesList = chat.getChatMessages();
        chatMessagesList.add(chatMessage);
        chat.setChatMessages(chatMessagesList);
        chatRepository.save(chat);

        String notiDes = "You have new messages in board " + chat.getChatName();
        String notiHeader = chat.getChatName();
        String url = "/Board/" + boardID;

        List<User> allUser = chat.getUser();
        for (int i=0;i<allUser.size();i++){
            List<Notification> notificationsList = notificationRepository.findAll();
            if(!currentUser.getUserID().equals(allUser.get(i).getUserID())){
                if(notificationsList.size() !=0){
                    Notification notification = new Notification(notificationsList.get(notificationsList.size()-1).getNotiID()+1L,date,notiDes);
                    notification.setReceiveUserID(allUser.get(i).getUserID());
                    notification.setHeader(notiHeader);
                    notification.setUrl(url);
                    notificationRepository.save(notification);
                }else{
                    Notification notification = new Notification(notificationsList.size()+1L,date,notiDes);
                    notification.setReceiveUserID(allUser.get(i).getUserID());
                    notification.setHeader(notiHeader);
                    notification.setUrl(url);
                    notificationRepository.save(notification);
                }
            }
        }

        setNotiDate();

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        model.addAttribute("allList", allList);

        return ResponseEntity.ok(chatMessage);
    }


    @GetMapping("/changeUnreadToRead")
    public ResponseEntity<String> changeUnreadToRead(ModelMap model,HttpServletRequest request) {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        List<Notification> allNoti = notificationRepository.findAllByReceiveUserID(currentUser.getUserID());

        for(int i=0;i<allNoti.size();i++){
            allNoti.get(i).setRead(true);
            notificationRepository.save(allNoti.get(i));
        }

        return ResponseEntity.ok("ok");
    }

    @GetMapping("/deleteNoti")
    public ResponseEntity<String> deleteNoti(ModelMap model,HttpServletRequest request) {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        List<Notification> allNoti = notificationRepository.findAllByReceiveUserID(currentUser.getUserID());

        for(int i=0;i<allNoti.size();i++){
            allNoti.get(i).setRead(true);
            notificationRepository.delete(allNoti.get(i));
        }


        return ResponseEntity.ok("ok");
    }


    @GetMapping("/Board/{boardID}")
    public String showAllTaskList(ModelMap model, @PathVariable Long boardID,HttpServletRequest request) {
        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        setChatTimeStamp();
        setChatDate();
        setDate(boardID);
        setNotiDate();

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        Chat chat = chatRepository.findByChatID(boardID);
        model.addAttribute("chat",chat);

        User currentUser = (User) request.getSession().getAttribute("currentUser");
        model.addAttribute("currentUser",currentUser);

        List<Notification> allNoti = notificationRepository.findAllByReceiveUserID(currentUser.getUserID());
        model.addAttribute("allNoti",allNoti);
        int unReadCount=0;
        for(int i=0;i<allNoti.size();i++){
            if(!allNoti.get(i).isRead()){
                unReadCount++;
            }
        }

        model.addAttribute("unReadCount",unReadCount);

        model.addAttribute("allList", allList);

        JSONArray arr = new JSONArray();
        JSONObject tmp;

        for(int i = 0; i < board.getUser().size(); i++) {
            for(int j=0;j<board.getUser().get(i).getAssignedTaskCard().size();j++){
                if(board.getUser().get(i).getAssignedTaskCard().get(j) != null){
                    tmp = new JSONObject();
                    tmp.put("userID",board.getUser().get(i).getUserID());
                    tmp.put("taskCardID",board.getUser().get(i).getAssignedTaskCard().get(j).getTaskCardID());
                    arr.add(tmp);
                }
            }
        }

        model.addAttribute("jsonArray",arr);

        return "Board";
    }

    public void setDate(Long boardID){
        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        Date tempStartDate;
        Date tempDueDate;
        DateFormat tempStartDateDF = new SimpleDateFormat("yyyy/MM/dd");
        DateFormat tempDueDateDF = new SimpleDateFormat("yyyy/MM/dd");
        String tempStartDateString;
        String tempDueDateString;

        String startDateReal="";
        String dueDateReal="";

        for(int i=0;i<allList.size();i++){
            for(int j=0;j<allList.get(i).getTaskCard().size();j++) {
                if(allList.get(i).getTaskCard().get(j).getStartDate() == null || allList.get(i).getTaskCard().get(j).getDueDate() == null){
                    break;
                }
                tempStartDate = allList.get(i).getTaskCard().get(j).getStartDate();
                tempStartDateString = tempStartDateDF.format(tempStartDate);

                for (int k = 0; k < tempStartDateString.length(); k++) {
                    if (tempStartDateString.charAt(k) != ' ') {
                        startDateReal = startDateReal + tempStartDateString.charAt(k);
                    } else {
                        break;
                    }
                }

                allList.get(i).getTaskCard().get(j).setStartDateString(startDateReal);
                startDateReal = "";

                tempDueDate = allList.get(i).getTaskCard().get(j).getDueDate();
                tempDueDateString = tempDueDateDF.format(tempDueDate);

                for (int y = 0; y < tempDueDateString.length(); y++) {
                    if (tempDueDateString.charAt(y) != ' ') {
                        dueDateReal = dueDateReal + tempDueDateString.charAt(y);
                    } else {
                        break;
                    }
                }
                allList.get(i).getTaskCard().get(j).setDueDateString(dueDateReal);
                dueDateReal = "";
            }
            taskListRepository.save(allList.get(i));
        }
    }

    public void setChatTimeStamp(){
        List<ChatMessage> allMessage = chatMessageRepository.findAll();
        Date tempTimeStamp;
        DateFormat tempTimeStampDF = new SimpleDateFormat("HH:mm");
        String tempTimeStampString;


        for(int i=0;i<allMessage.size();i++){
            if(allMessage.get(i).getTimeStamp() == null){
                break;
            }
            tempTimeStamp = allMessage.get(i).getTimeStamp();
            tempTimeStampString = tempTimeStampDF.format(tempTimeStamp);

            allMessage.get(i).setTimeStampString(tempTimeStampString);

            chatMessageRepository.save(allMessage.get(i));
        }
    }

    public void setChatDate(){
        List<ChatMessage> allMessage = chatMessageRepository.findAll();
        Date tempTimeStamp;
        DateFormat tempTimeStampDF = new SimpleDateFormat("EEEEE dd/MM/yyyy");
        String tempTimeStampString;


        for(int i=0;i<allMessage.size();i++){
            if(allMessage.get(i).getTimeStamp() == null){
                break;
            }
            tempTimeStamp = allMessage.get(i).getTimeStamp();
            tempTimeStampString = tempTimeStampDF.format(tempTimeStamp);

            allMessage.get(i).setDateString(tempTimeStampString);

            chatMessageRepository.save(allMessage.get(i));
        }
    }

    public void setNotiDate(){
        List<Notification> allNoti = notificationRepository.findAll();
        Date tempTimeStamp;
        DateFormat tempTimeStampDF = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        String tempTimeStampString;


        for(int i=0;i<allNoti.size();i++){
            if(allNoti.get(i).getDate() == null){
                break;
            }
            tempTimeStamp = allNoti.get(i).getDate();
            tempTimeStampString = tempTimeStampDF.format(tempTimeStamp);

            allNoti.get(i).setDateString(tempTimeStampString);

            notificationRepository.save(allNoti.get(i));
        }
    }

}
