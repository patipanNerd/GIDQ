package com.gidq.gidq.controller;

import com.gidq.gidq.model.Board;
import com.gidq.gidq.model.Notification;
import com.gidq.gidq.model.User;
import com.gidq.gidq.repository.NotificationRepository;
import com.gidq.gidq.repository.UserRepository;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.SessionScope;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;


@Controller
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    @GetMapping("/Login")
    public String LoginPage() {
        return "Login";
    }

    @GetMapping("/Signup")
    public String signupPage() {
        return "Signup";
    }

    @PostMapping("/Signup")
    public String createUser(ModelMap model, HttpServletRequest request) {
        String email = request.getParameter("email");
        String fullnameTemp = request.getParameter("fullname");
        String password = request.getParameter("password");
        String rePassword = request.getParameter("rePassword");

        String[] fullname = fullnameTemp.split("\\s+");
        String firstName = fullname[0];
        String lastName= fullname[1];

        if(!password.equals(rePassword)){
            model.addAttribute("errorMSG", "Password Mismatch");
            return "Signup";
        }

        User user = userRepository.findByEmail(email);
        if(user != null){
            if(user.getEmail().equals(email)){
                model.addAttribute("errorMSG", "This E-mail Already Registered");
                return "Signup";
            }
        }

        List<User> allUser = userRepository.findAll();

        PasswordEncoder encoder = new BCryptPasswordEncoder();


        User account = new User(allUser.size()+1L,email,firstName,lastName,encoder.encode(password));

        userRepository.save(account);


        return "redirect:/Login";
    }

    @PostMapping("/Login")
    public String Login(ModelMap model, HttpServletRequest request){
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        boolean emailToken = false;
        boolean passToken = false;
        Long userID = null;
        PasswordEncoder encoder = new BCryptPasswordEncoder();


        List<User> allUser = userRepository.findAll();

        for(int i=0;i<allUser.size();i++){
            if(allUser.get(i).getEmail().equals(email)){
                emailToken = true;
                userID = allUser.get(i).getUserID();
                break;
            }
        }
        User userTemp = userRepository.findByUserID(userID);
        if(!emailToken){
            model.addAttribute("errorMSG", "Incorrect Email or Password.");
            return "Login";
        }else{
            if(!encoder.matches(password,userTemp.getPassword())){
                model.addAttribute("errorMSG", "Incorrect Email or Password.");
                return "Login";
            }
        }

        User currentUser = userRepository.findByUserID(userID);
        model.addAttribute("currentUser", currentUser);

        request.getSession().setAttribute("currentUser",currentUser);

        return "redirect:/AllProject";
    }

    @GetMapping("/Profile")
    public String ProfilePage(ModelMap model,HttpServletRequest request) {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        model.addAttribute("currentUser",currentUser);

        List<Notification> allNoti = notificationRepository.findAllByReceiveUserID(currentUser.getUserID());
        model.addAttribute("allNoti",allNoti);

        int unReadCount=0;
        for(int i=0;i<allNoti.size();i++){
            if(!allNoti.get(i).isRead()){
                unReadCount++;
            }
        }

        model.addAttribute("unReadCount",unReadCount);

        return "Profile";
    }

    @PostMapping("/Profile/editedName")
    public String editName(ModelMap model,HttpServletRequest request) {
        User currentUser = (User) request.getSession().getAttribute("currentUser");

        String fullNameTemp = request.getParameter("fullName");

        String[] fullName = fullNameTemp.split("\\s+");

        String firstName = fullName[0];
        currentUser.setFirstName(firstName);
        if(fullName.length >1) {
            String lastName = fullName[1];
            currentUser.setLastName(lastName);
        }else{
            currentUser.setLastName("");
        }
        userRepository.save(currentUser);

        return "redirect:/Profile";
    }

    @PostMapping("/Profile/editedPassword")
    public String editPassword(ModelMap model,HttpServletRequest request) {
        User currentUser = (User) request.getSession().getAttribute("currentUser");

        String password = request.getParameter("Re-typePass");
        currentUser.setPassword(password);

        userRepository.save(currentUser);

        return "redirect:/Profile";
    }

    @GetMapping("/Logout")
    public String LogoutPage() {
        return "redirect:/Login";
    }

    @PostMapping("/Profile/uploadedProfileImage")
    public String saveImage(@RequestParam("file") MultipartFile submissions,ModelMap model,HttpServletRequest request) throws IOException, SQLException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");

        byte[] bytes = submissions.getBytes();
        Blob blob = new javax.sql.rowset.serial.SerialBlob(bytes);

        currentUser.setProfileImage(blob);

        userRepository.save(currentUser);

        return "redirect:/Profile";
    }

    @RequestMapping(value = "/Profile/showImage", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getImage(HttpServletRequest request) throws IOException, SQLException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        byte[] imageContent = currentUser.getProfileImage().getBytes(1, (int)currentUser.getProfileImage().length());//get image from DAO based on id
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_PNG);
        return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
    }

    @RequestMapping(value = "/Profile/{userID}/showIndividualImage", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> showImage(HttpServletRequest request,@PathVariable Long userID) throws IOException, SQLException {
        User user = userRepository.findByUserID(userID);
        byte[] imageContent = user.getProfileImage().getBytes(1, (int)user.getProfileImage().length());//get image from DAO based on id
        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_PNG);
        return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
    }

}


