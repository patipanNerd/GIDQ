package com.gidq.gidq.repository;

import com.gidq.gidq.model.TaskList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskListRepository extends JpaRepository<TaskList,Long> {
    List<TaskList> findAllByBoard_BoardID(Long boardID);
    TaskList findByListID(Long listID);
}
