package com.gidq.gidq.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
public class Notification {

    @Id
    private Long notiID;
    private Date date;
    private String description;
    private String dateString;
    private String header;
    private String url;
    private boolean isRead;
    private Long receiveUserID;

    public Notification(){

    }

    public Notification(Long notiID,Date date, String description) {
        this.notiID = notiID;
        this.date = date;
        this.description = description;
        this.dateString = null;
        this.header = null;
        this.url = null;
        this.isRead = false;
    }

    public Long getNotiID() {
        return notiID;
    }

    public void setNotiID(Long notiID) {
        this.notiID = notiID;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
