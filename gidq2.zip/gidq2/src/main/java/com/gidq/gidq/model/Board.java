package com.gidq.gidq.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
public class Board {

    @Id
    private Long boardID;
    private String boardName;
    private String description;
    private String background;
    private Boolean isFavorite;

    @ManyToMany(cascade = CascadeType.MERGE)
    private List<User> user;

    public Board() {
    }


    public Board(Long boardID,String boardName,String description,String background,Boolean isFavorite) {
        this.boardID = boardID;
        this.boardName = boardName;
        this.description = description;
        this.background = background;
        this.isFavorite = isFavorite;
    }



    public Long getBoardID() {
        return boardID;
    }

    public void setBoardID(Long boardID) {
        this.boardID = boardID;
    }

    public String getBoardName() {
        return boardName;
    }

    public void setBoardName(String boardName) {
        this.boardName = boardName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    public Boolean getFavorite() {
        return isFavorite;
    }

    public void setFavorite(Boolean favorite) {
        isFavorite = favorite;
    }

    public List<User> getUser() {
        return user;
    }

    public void setUser(List<User> user) {
        this.user = user;
    }
}
