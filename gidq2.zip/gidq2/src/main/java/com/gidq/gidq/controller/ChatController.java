package com.gidq.gidq.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class ChatController {

}
