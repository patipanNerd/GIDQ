package com.gidq.gidq.controller;

public class ChatMessageController {
}
