package com.gidq.gidq.model;

import lombok.Getter;
import lombok.Setter;


import javax.persistence.*;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
public class TaskCard {

    @Id
    private Long taskCardID;
    private String cardName;
    private String description;
    private Date startDate;
    private String startDateString;
    private String dueDateString;
    private Date dueDate;
    private int percent;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "taskList_listID" , nullable = false)
    private TaskList taskList;


    public TaskCard() {
    }

    public TaskCard(Long taskCardID,String cardName,String description) {
        this.taskCardID = taskCardID;
        this.cardName = cardName;
        this.description = description;
        this.startDate = null;
        this.dueDate = null;
        this.percent = 0;
        this.startDateString=null;
        this.dueDate=null;
    }


    public Long getTaskCardID() {
        return taskCardID;
    }

    public void setTaskCardID(Long taskCardID) {
        this.taskCardID = taskCardID;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

}
