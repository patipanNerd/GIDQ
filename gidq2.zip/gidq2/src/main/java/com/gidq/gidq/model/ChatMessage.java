package com.gidq.gidq.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Blob;
import java.util.Date;

@Getter
@Setter
@Entity
public class ChatMessage {

    @Id
    private Long messageID;
    private String message;
    private Date timeStamp;
    private Long senderID;
    private String timeStampString;
    private String dateString;
    @Lob
    private Blob attachment;

    public ChatMessage() {
    }
    public ChatMessage(Long messageID,String message,Date timeStamp,Long senderID) {
        this.messageID = messageID;
        this.message = message;
        this.timeStamp = timeStamp;
        this.senderID = senderID;
        this.timeStampString = null;
        this.dateString = null;
    }

    public Long getMessageID() {
        return messageID;
    }

    public void setMessageID(Long messageID) {
        this.messageID = messageID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public Long getSenderID() {
        return senderID;
    }

    public void setSenderID(Long senderID) {
        this.senderID = senderID;
    }
}
