package com.gidq.gidq.controller;

import com.gidq.gidq.model.Board;
import com.gidq.gidq.repository.BoardRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Optional;

@Controller
public class TaskListController {



}
