package com.gidq.gidq.controller;

import com.gidq.gidq.model.*;
import com.gidq.gidq.repository.*;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.GsonJsonParser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class ScheduleController {

    @Autowired
    BoardRepository boardRepository;

    @Autowired
    TaskListRepository taskListRepository;

    @Autowired
    TaskCardRepository taskCardRepository;

    @Autowired
    ChatRepository chatRepository;

    @Autowired
    ChatMessageRepository chatMessageRepository;

    @Autowired
    NotificationRepository notificationRepository;

    @GetMapping("/Schedule/{boardID}")
    public String showSchedule(ModelMap model, @PathVariable Long boardID, HttpServletRequest request) {
        setChatTimeStamp();
        setChatDate();
        setDate(boardID);

        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);

        JSONArray arr = new JSONArray();
        JSONObject tmp;
            for(int i = 0; i < allList.size(); i++) {
                for(int j=0;j<allList.get(i).getTaskCard().size();j++){
                    if(allList.get(i).getTaskCard().get(j).getStartDateString() != null && allList.get(i).getTaskCard().get(j).getDueDateString() != null){
                        tmp = new JSONObject();
                        tmp.put("taskCardID",allList.get(i).getTaskCard().get(j).getTaskCardID());
                        tmp.put("cardName",allList.get(i).getTaskCard().get(j).getCardName());
                        tmp.put("resource",allList.get(i).getListName());
                        tmp.put("startDate",allList.get(i).getTaskCard().get(j).getStartDateString());
                        tmp.put("dueDate",allList.get(i).getTaskCard().get(j).getDueDateString());
                        tmp.put("percent",allList.get(i).getTaskCard().get(j).getPercent());

                        arr.add(tmp);
                    }
                }
            }

        model.addAttribute("jsonArray",arr);
        model.addAttribute("allList", allList);

        Chat chat = chatRepository.findByChatID(boardID);
        model.addAttribute("chat",chat);

        User currentUser = (User) request.getSession().getAttribute("currentUser");
        model.addAttribute("currentUser",currentUser);

        List<Notification> allNoti = notificationRepository.findAllByReceiveUserID(currentUser.getUserID());
        model.addAttribute("allNoti",allNoti);

        int unReadCount=0;
        for(int i=0;i<allNoti.size();i++){
            if(!allNoti.get(i).isRead()){
                unReadCount++;
            }
        }

        model.addAttribute("unReadCount",unReadCount);

        Board board = boardRepository.findByBoardID(boardID);
        model.addAttribute("board", board);

        return "Schedule";
    }


    public void setDate(Long boardID){
        List<TaskList> allList = taskListRepository.findAllByBoard_BoardID(boardID);
        Date tempStartDate;
        Date tempDueDate;
        DateFormat tempStartDateDF = new SimpleDateFormat("yyyy/MM/dd");
        DateFormat tempDueDateDF = new SimpleDateFormat("yyyy/MM/dd");
        String tempStartDateString;
        String tempDueDateString;

        String startDateReal="";
        String dueDateReal="";

        for(int i=0;i<allList.size();i++){
            for(int j=0;j<allList.get(i).getTaskCard().size();j++) {
                if(allList.get(i).getTaskCard().get(j).getStartDate() == null || allList.get(i).getTaskCard().get(j).getDueDate() == null){
                    break;
                }
                tempStartDate = allList.get(i).getTaskCard().get(j).getStartDate();
                tempStartDateString = tempStartDateDF.format(tempStartDate);

                for (int k = 0; k < tempStartDateString.length(); k++) {
                    if (tempStartDateString.charAt(k) != ' ') {
                        startDateReal = startDateReal + tempStartDateString.charAt(k);
                    } else {
                        break;
                    }
                }

                allList.get(i).getTaskCard().get(j).setStartDateString(startDateReal);
                startDateReal = "";

                tempDueDate = allList.get(i).getTaskCard().get(j).getDueDate();
                tempDueDateString = tempDueDateDF.format(tempDueDate);

                for (int y = 0; y < tempDueDateString.length(); y++) {
                    if (tempDueDateString.charAt(y) != ' ') {
                        dueDateReal = dueDateReal + tempDueDateString.charAt(y);
                    } else {
                        break;
                    }
                }
                allList.get(i).getTaskCard().get(j).setDueDateString(dueDateReal);
                dueDateReal = "";
            }
            taskListRepository.save(allList.get(i));
        }
    }

    public void setChatTimeStamp(){
        List<ChatMessage> allMessage = chatMessageRepository.findAll();
        Date tempTimeStamp;
        DateFormat tempTimeStampDF = new SimpleDateFormat("HH:mm");
        String tempTimeStampString;


        for(int i=0;i<allMessage.size();i++){
                if(allMessage.get(i).getTimeStamp() == null){
                    break;
                }
                tempTimeStamp = allMessage.get(i).getTimeStamp();
                tempTimeStampString = tempTimeStampDF.format(tempTimeStamp);

                allMessage.get(i).setTimeStampString(tempTimeStampString);

            chatMessageRepository.save(allMessage.get(i));
        }
    }

    public void setChatDate(){
        List<ChatMessage> allMessage = chatMessageRepository.findAll();
        Date tempTimeStamp;
        DateFormat tempTimeStampDF = new SimpleDateFormat("EEEEE dd/MM/yyyy");
        String tempTimeStampString;


        for(int i=0;i<allMessage.size();i++){
            if(allMessage.get(i).getTimeStamp() == null){
                break;
            }
            tempTimeStamp = allMessage.get(i).getTimeStamp();
            tempTimeStampString = tempTimeStampDF.format(tempTimeStamp);

            allMessage.get(i).setDateString(tempTimeStampString);

            chatMessageRepository.save(allMessage.get(i));
        }
    }
}
