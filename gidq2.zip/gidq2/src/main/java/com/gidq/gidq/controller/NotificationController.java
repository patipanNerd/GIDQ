package com.gidq.gidq.controller;

public class NotificationController {
}
