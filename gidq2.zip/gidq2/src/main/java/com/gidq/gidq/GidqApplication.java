package com.gidq.gidq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class GidqApplication {

    public static void main(String[] args) {
        SpringApplication.run(GidqApplication.class, args);
    }

}
