package com.gidq.gidq.repository;

import com.gidq.gidq.model.TaskCard;
import com.gidq.gidq.model.TaskList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskCardRepository extends JpaRepository<TaskCard,Long> {
    TaskCard findByTaskCardID(Long cardID);
}
