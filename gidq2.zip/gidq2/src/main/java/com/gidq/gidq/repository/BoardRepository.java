package com.gidq.gidq.repository;

import com.gidq.gidq.model.Board;
import com.gidq.gidq.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BoardRepository extends JpaRepository<Board,Long> {
    List<Board> findAllByIsFavoriteIsFalse();
    List<Board> findAllByIsFavoriteIsTrue();
    Board findByBoardID(Long boardID);
    List<Board> findAllByUserAndIsFavoriteIsFalse(User user);
    List<Board> findAllByUserAndIsFavoriteIsTrue(User user);
}
