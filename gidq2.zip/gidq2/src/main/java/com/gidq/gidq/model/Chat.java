package com.gidq.gidq.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
public class Chat {

    @Id
    private Long chatID;
    private String chatName;

    @ManyToMany(cascade = CascadeType.MERGE)
    private List<User> user;

    @OneToMany(cascade = CascadeType.MERGE)
    private List<ChatMessage> chatMessages;

    public Chat() {
    }

    public Chat(Long chatID,String chatName) {
        this.chatID = chatID;
        this.chatName = chatName;
    }

    public Long getChatID() {
        return chatID;
    }

    public void setChatID(Long chatID) {
        this.chatID = chatID;
    }

    public String getChatName() {
        return chatName;
    }

    public void setChatName(String chatName) {
        this.chatName = chatName;
    }

    public List<User> getUser() {
        return user;
    }

    public void setUser(List<User> user) {
        this.user = user;
    }

    public List<ChatMessage> getChatMessages() {
        return chatMessages;
    }

    public void setChatMessages(List<ChatMessage> chatMessages) {
        this.chatMessages = chatMessages;
    }
}
