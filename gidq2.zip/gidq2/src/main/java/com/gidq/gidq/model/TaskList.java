package com.gidq.gidq.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
public class TaskList {

    @Id
    private Long listID;
    private String listName;
    private int cardQuantity=0;
    private String colorCode;

    @ManyToOne(cascade = CascadeType.MERGE)
    private Board board;

    @OneToMany(cascade = CascadeType.MERGE, mappedBy = "taskList")
    private List<TaskCard> taskCard;

    public TaskList() {
    }

    public TaskList(Long listID,String listName,int cardQuantity) {
        this.listID = listID;
        this.listName = listName;
        this.cardQuantity = cardQuantity;
        this.colorCode=null;
    }

    public Long getListID() {
        return listID;
    }

    public void setListID(Long listID) {
        this.listID = listID;
    }

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public int getCardQuantity() {
        return cardQuantity;
    }

    public void setCardQuantity(int cardQuantity) {
        this.cardQuantity = cardQuantity;
    }

    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public List<TaskCard> getTaskCard() {
        return taskCard;
    }

    public void setTaskCard(List<TaskCard> taskCard) {
        this.taskCard = taskCard;
    }


}
