// Get the modal
var modal = document.getElementById('myModal');

function modalOpen(){
  modal.style.display = "block";
}

function modalClose(){
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    location.reload();
  }
}

$('#myModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var arrayData = button.data('whatever') // Extract info from data-* attributes
  var arr = arrayData.split(',');

  var cardName = arr[0];
  var listName = arr[1];
  var description = arr[2];
  var cardID = arr[3];
  var boardID = arr[4];
  var startDate = arr[5];
  var dueDate = arr[6];
  var percent = arr[7];

  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('#modal-title').text('Edit '+cardName)
  modal.find('#modalListName').text(listName)
  modal.find('#modalBoardID').text(boardID)

  modal.find('#modalTaskCardID').text(cardID)
  modal.find('#modalTaskCardID').value = cardID;
  modal.find('#modalTaskCardDescription').text('' + description)
  modal.find('#percentDone').val(percent)

  if(startDate === "null"){
    modal.find('#modalTaskCardStartDate').val('yyyy/mm/dd')
  }else{
    modal.find('#modalTaskCardStartDate').val(startDate)
  }

  if(dueDate === "null"){
    modal.find('#modalTaskCardDueDate').val('yyyy/mm/dd')
  }else{
    modal.find('#modalTaskCardDueDate').val(dueDate)
  }

  var tempCardID = getTaskCardIDForModal();

  var rawJSON = button.data('user');

  var taskCardID = [];
  var userID = [];

  for(i=0;i<rawJSON.length;i++){
    taskCardID[i] = rawJSON[i].taskCardID;
    userID[i] = rawJSON[i].userID;
  }

  for(j=0;j<taskCardID.length;j++){
    if(taskCardID[j].toString() === tempCardID){
      $('#imgView').append('<img class="img-fluid rounded-circle border-2-white profile-pic-modal ml-1 mr-1"\n' +
          '  src="/Profile/'+userID[j]+'/showIndividualImage">')
    }
  }


})

function form_submit() {
  document.getElementById("postModalForm").submit();
}

// google gantt chart
  google.charts.load('current', {'packages':['gantt']});
  google.charts.setOnLoadCallback(drawChart);

  function drawChart() {
    var rawJSON = document.getElementById("json").getAttribute('data');
    var obj = JSON.parse(rawJSON);


    var startDay = new Array()
    var startMonth = new Array()
    var startYear = new Array()
    var dueDay = new Array()
    var dueMonth = new Array()
    var dueYear = new Array()

    for (i = 0; i < obj.length; i++) {
      if(obj[i].startDate != null){
        var arr = obj[i].startDate.split('/');
        startDay[i] = arr[2]
        startMonth[i] = arr[1]
        startYear[i] = arr[0]
      }

    }

    for (j = 0; j < obj.length; j++) {
      if(obj[j].dueDate != null){
        var arr2 = obj[j].dueDate.split('/');
        dueDay[j] = arr2[2]
        dueMonth[j] = arr2[1]
        dueYear[j] = arr2[0]
      }
    }


    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Task ID');
    data.addColumn('string', 'Task Name');
    data.addColumn('string', 'Resource');
    data.addColumn('date', 'Start Date');
    data.addColumn('date', 'End Date');
    data.addColumn('number', 'Duration');
    data.addColumn('number', 'Percent Complete');
    data.addColumn('string', 'Dependencies');

    for(k=0;k<obj.length;k++){
      if(obj[k].startDate != null && obj[k].dueDate != null){
        data.addRows([
          [obj[k].taskCardID.toString(),obj[k].cardName,obj[k].resource,new Date(startYear[k],startMonth[k],startDay[k])
            ,new Date(dueYear[k],dueMonth[k],dueDay[k]),null,obj[k].percent,null]
        ]);
      }

    }

    var trackHeight = 46.5;
    var rows = data.getNumberOfRows()+3;

    var options = {
      width: $(window).width()*0.6,
      height: rows * trackHeight,
      backgroundColor: {
        fill: '#F7F7F7'
      },
      gantt: {
        innerGridTrack: {fill: '#FFFFFF'},
        innerGridDarkTrack: {fill: '#FFFFFF'},
        trackHeight: 46,
        palette:[
          {
            "color": "#5e97f6",
            "dark": "#2a56c6",
            "light": "#c6dafc"
          },
          {
            "color": "#db4437",
            "dark": "#a52714",
            "light": "#f4c7c3"
          },
          {
            "color": "#f2a600",
            "dark": "#ee8100",
            "light": "#fce8b2"
          },
          {
            "color": "#0f9d58",
            "dark": "#0b8043",
            "light": "#b7e1cd"
          },
          {
            "color": "#ab47bc",
            "dark": "#6a1b9a",
            "light": "#e1bee7"
          },
          {
            "color": "#00acc1",
            "dark": "#00838f",
            "light": "#b2ebf2"
          },
          {
            "color": "#ff7043",
            "dark": "#e64a19",
            "light": "#ffccbc"
          },
          {
            "color": "#9e9d24",
            "dark": "#827717",
            "light": "#f0f4c3"
          },
          {
            "color": "#5c6bc0",
            "dark": "#3949ab",
            "light": "#c5cae9"
          },
          {
            "color": "#f06292",
            "dark": "#e91e63",
            "light": "#f8bbd0"
          },
          {
            "color": "#00796b",
            "dark": "#004d40",
            "light": "#b2dfdb"
          },
          {
            "color": "#c2185b",
            "dark": "#880e4f",
            "light": "#f48fb1"
          }
        ]
      }
    };

    var chart = new google.visualization.Gantt(document.getElementById('chart_div'));

    chart.draw(data, options);
  }




function clickList(taskListID){
var iconID = "icon" + taskListID;
var hideID = "hide" + taskListID;
  if (document.getElementById(iconID).className === "las la-plus-square text-18") {
    document.getElementById(iconID).className = "las la-minus-square text-18"
    $('#'+hideID).toggle();
  } else {
    document.getElementById(iconID).className = "las la-plus-square text-18"
    $('#'+hideID).toggle();
  }
}

$(document).ready(function(){
  $("#name-edit-btn").click(function(){
    $(".edit-name").show();
    $("#save-name-edit-btn").show();
    $("#cancel-name-edit-btn").show();
    $("#name-edit-btn").hide();
  });
});

$(document).ready(function(){
  $("#pass-edit-btn").click(function(){
    $(".edit-password").show();
    $("#save-pass-edit-btn").show();
    $("#cancel-pass-edit-btn").show();
    $("#pass-edit-btn").hide();
  });
});

$(document).ready(function(){
  $("#changeProfileImage-btn").click(function(){
    $(".changeProfileImage").show();
  });
});


$(document).ready(function(){
  // Check if passwords match

  $('#NewPass, #Re-typePass').on('keyup', function () {
    if ($('#NewPass').val() != '' && $('#Re-typePass').val() != '' && $('#NewPass').val() === $('#Re-typePass').val()) {
      $("#save-pass-edit-btn").attr("disabled",false);
      $('#cPwdValid').show();
      $('#cPwdInvalid').hide();
      $('#cPwdValid').html('Valid').css('color', 'green');
      $('.pwds').removeClass('is-invalid')
    } else if($('#NewPass').val() != '' && $('#Re-typePass').val() != '' && $('#NewPass').val() !== $('#Re-typePass').val()){
      $("#save-pass-edit-btn").attr("disabled",true);
      $('#cPwdValid').hide();
      $('#cPwdInvalid').show();
      $('#cPwdInvalid').html('password mismatch').css('color', 'red');
      $('.pwds').addClass('is-invalid')
    }
  });
  let currForm1 = document.getElementById('ChangePwdForm');
  // Validate on submit:
  currForm1.addEventListener('submit', function(event) {
    if (currForm1.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }
    currForm1.classList.add('was-validated');
  }, false);
  // Validate on input:
  currForm1.querySelectorAll('.form-control').forEach(input => {
    input.addEventListener(('input'), () => {
      if(input.checkValidity() && $('#NewPass').val() !== $('#Re-typePass').val() && $('#Re-typePass').val() !=''){
        input.classList.remove('is-valid')
        input.classList.add('is-invalid');
      }else if (input.checkValidity()) {
        input.classList.remove('is-invalid')
        input.classList.add('is-valid');
      }else{
        input.classList.remove('is-valid')
        input.classList.add('is-invalid');
      }
      var is_valid = $('.form-control').length === $('.form-control.is-valid').length;
      $("#submitBtn").attr("disabled", !is_valid);
    });
  });
});

// Noti dropdown
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

// Noti entire div clickable
$(".noti-item").click(function() {
  window.location = $(this).find("a").attr("href");
  return false;
});

function notiFunction() {
  var x = document.getElementById("show-noti");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }


  $.ajax({
    url : '/changeUnreadToRead',
    success : function() {
    }
  });

  $("#notiBadge").remove();
}


// assign task
function assignFunction() {
  var x = document.getElementById("assign-task");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}

// cler noti
function clearNotiFunction() {
  var myobj = document.getElementById("notification-list");
  myobj.remove();

  $.ajax({
    url : '/deleteNoti',
    success : function() {
    }
  });
}

function getTaskCardIDForModal(){
  var taskCardID = document.getElementById("modalTaskCardID").value;

  return taskCardID;
}