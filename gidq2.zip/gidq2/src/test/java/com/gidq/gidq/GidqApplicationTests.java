package com.gidq.gidq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GidqApplicationTests {

    @Test
    void contextLoads() {
    }

}
